import React from "react";

const GetHired = () => {
  return <div>Work In Progress!</div>;
};

export default GetHired;
