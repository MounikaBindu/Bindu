const Cdata = [
  {
    id: "1",
    imgScr:
      "https://images.unsplash.com/photo-1614963326505-843868e1d83a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Video Editing",
    date: "28/12/2021",
    content:
      "Writing and editing copy as well as adapting pictures and multimedia for social media platforms.",
  },
  {
    id: "2",
    imgScr:
      "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Technical Paper",
    date: "18/03/2022",
    content:
      "Correcting errors, loading paper, and adjusting equipment settings. Performing preventative maintenance.",
  },
  {
    id: "3",
    imgScr:
      "https://images.unsplash.com/photo-1599658880436-c61792e70672?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Data entry",
    date: "06/09/2020",
    content:
      "Scoping important data from Construction documents Entering data into our software to run simulations",
  },
  {
    id: "4",
    imgScr:
      "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Logo design",
    date: "18/10/2022",
    content:
      "Design and manage customer online portfolios and website. Create and/or edit graphics for website and/or Facebook page.",
  },
  {
    id: "5",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "7",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "8",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "9",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "10",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "11",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "12",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "13",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
  {
    id: "1",
    imgScr:
      "https://images.unsplash.com/photo-1614963326505-843868e1d83a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Video Editing",
    date: "28/12/2021",
    content:
      "Writing and editing copy as well as adapting pictures and multimedia for social media platforms.",
  },
  {
    id: "2",
    imgScr:
      "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Technical Paper",
    date: "18/03/2022",
    content:
      "Correcting errors, loading paper, and adjusting equipment settings. Performing preventative maintenance.",
  },
  {
    id: "3",
    imgScr:
      "https://images.unsplash.com/photo-1599658880436-c61792e70672?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Data entry",
    date: "06/09/2020",
    content:
      "Scoping important data from Construction documents Entering data into our software to run simulations",
  },
  {
    id: "4",
    imgScr:
      "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "Logo design",
    date: "18/10/2022",
    content:
      "Design and manage customer online portfolios and website. Create and/or edit graphics for website and/or Facebook page.",
  },
  {
    id: "5",
    imgScr: "https://picsum.photos/200/130",
    title: "Editing",
    date: "06/09/2006",
    content:
      "Sax asperiores numquam deleniti ducimus alias quasi esse voluptas sed necessitatibus animi nesciunt, maxime perferendis dolorem. Aliquam!",
  },
];

export default Cdata;
